"use client";
import { useState, useEffect } from "react";
import { GoogleGenerativeAI } from "@google/generative-ai";
import ImageUpload from "./components/ImageUpload";
import Login from "./components/Login";
import Signup from "./components/Signup";
import { supabase } from "./lib/supabaseClient";

interface PlantInfo {
  name: string;
  scientific_name: string;
  description: string;
  care_instructions: string;
  native_regions: string;
  interesting_facts: string[];
}

export default function Home() {
  const [image, setImage] = useState<File | null>(null);
  const [plantInfo, setPlantInfo] = useState<PlantInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [useCount, setUseCount] = useState(0);
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user || null);
      }
    );

    // Check current session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user || null);
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handleImageUpload = (file: File) => {
    setImage(file);
  };

  const identifyPlant = async () => {
    if (!image) return;
    if (useCount >= 1 && !user) {
      setShowLogin(true);
      return;
    }
    setLoading(true);
    setPlantInfo(null);
    const genAI = new GoogleGenerativeAI(
      process.env.NEXT_PUBLIC_GOOGLE_GEMINI_API_KEY!
    );
    const model = genAI.getGenerativeModel({
      model: process.env.NEXT_PUBLIC_GOOGLE_GEMINI_MODEL,
    });

    try {
      const imageParts = await fileToGenerativePart(image);
      const result = await model.generateContent([
        "Identify this plant and provide the following information: name, scientific name, brief description, care instructions, native regions, and 3 interesting facts. Format the response as JSON with the following keys: name, scientific_name, description, care_instructions, native_regions, interesting_facts (as an array).",
        imageParts,
      ]);
      const response = await result.response;
      const text = await response.text();

      // Extract JSON from the response
      const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/);
      if (jsonMatch && jsonMatch[1]) {
        const jsonString = jsonMatch[1];
        const parsedInfo: PlantInfo = JSON.parse(jsonString);
        setPlantInfo(parsedInfo);
        setUseCount((prevCount) => prevCount + 1);
      } else {
        throw new Error("Unable to extract JSON from the response");
      }
    } catch (error) {
      console.error("Error identifying plant:", error);
      setPlantInfo(null);
    } finally {
      setLoading(false);
    }
  };

  async function fileToGenerativePart(file: File) {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result!.split(",")[1]);
      reader.readAsDataURL(file);
    });
    return {
      inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
  }

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setUseCount(0);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
          Plant Identifier
        </h1>
        {user ? (
          <button
            onClick={handleLogout}
            className="mb-4 bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-600 transition duration-300"
          >
            Logout
          </button>
        ) : (
          <div className="mb-4">
            <button
              onClick={() => setShowLogin(true)}
              className="mr-2 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition duration-300"
            >
              Login
            </button>
            <button
              onClick={() => setShowSignup(true)}
              className="bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 transition duration-300"
            >
              Sign Up
            </button>
          </div>
        )}
        <ImageUpload onImageUpload={handleImageUpload} />
        <button
          onClick={identifyPlant}
          disabled={!image || loading}
          className="w-full bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed mt-4"
        >
          {loading ? "Identifying..." : "Identify Plant"}
        </button>
        {plantInfo && (
          <div className="mt-6 bg-gray-100 rounded-md overflow-hidden">
            <div className="bg-green-500 text-white py-2 px-4">
              <h2 className="text-xl font-semibold">{plantInfo.name}</h2>
              <p className="text-sm italic">{plantInfo.scientific_name}</p>
            </div>
            <div className="p-4">
              <h3 className="font-semibold mb-2">Description:</h3>
              <p className="text-gray-700 mb-4">{plantInfo.description}</p>
              <h3 className="font-semibold mb-2">Care Instructions:</h3>
              <p className="text-gray-700 mb-4">
                {plantInfo.care_instructions}
              </p>
              <h3 className="font-semibold mb-2">Native Regions:</h3>
              <p className="text-gray-700 mb-4">{plantInfo.native_regions}</p>
              <h3 className="font-semibold mb-2">Interesting Facts:</h3>
              <ul className="list-disc pl-5">
                {plantInfo.interesting_facts.map((fact, index) => (
                  <li key={index} className="text-gray-700 mb-2">
                    {fact}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
      {showLogin && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <Login
            onLogin={() => {
              setShowLogin(false);
              setUseCount(0);
            }}
          />
          <button
            onClick={() => setShowLogin(false)}
            className="absolute top-4 right-4 text-white"
          >
            Close
          </button>
        </div>
      )}
      {showSignup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <Signup
            onSignup={() => {
              setShowSignup(false);
              setUseCount(0);
            }}
          />
          <button
            onClick={() => setShowSignup(false)}
            className="absolute top-4 right-4 text-white"
          >
            Close
          </button>
        </div>
      )}
    </main>
  );
}
