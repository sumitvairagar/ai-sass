export interface PlantInfo {
    name: string;
    scientific_name: string;
    description: string;
    care_instructions: string;
    native_regions: string;
    interesting_facts: string[];
  }
  